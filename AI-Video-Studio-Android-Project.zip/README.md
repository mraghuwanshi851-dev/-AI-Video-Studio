# AI Video Studio (Android starter)

Hindi-first Android starter project with a dark UI, image picker, prompt field, format selector, and a GitHub Actions workflow that builds and uploads a debug APK artifact.

## Important
This is a starter app UI. It does **not** generate videos yet. Connect a legitimate AI video-generation API/service to implement real generation. Keep API keys on a backend; do not put secret API keys in the Android app or GitHub source.

## Build APK with GitHub Actions from an Android phone
1. Download and unzip this project.
2. Open your GitHub repository in Chrome and upload the files/folders from this project to the repository root. Make sure `.github/workflows/android.yml` is included.
3. Commit the files to `main` (or `master`).
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and tap **Run workflow** (or wait for the push workflow).
6. Open the completed workflow run and download the **AI-Video-Studio-APK** artifact.
7. Unzip the artifact; the file inside is `app-debug.apk`.

## Build output path
`app/build/outputs/apk/debug/app-debug.apk`

## Requirements
- Android Studio/Android SDK for local builds, or GitHub Actions for cloud builds.
- Gradle 8.9 and JDK 17 are used by the workflow.
