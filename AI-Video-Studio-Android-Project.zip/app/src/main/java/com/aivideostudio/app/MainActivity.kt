package com.aivideostudio.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private var selectedImage: Uri? = null
    private lateinit var imageStatus: TextView
    private lateinit var promptInput: EditText
    private lateinit var generateButton: Button

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int = 18): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun button(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(119, 74, 255), 14)
        minHeight = dp(52)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 22)
        window.navigationBarColor = Color.rgb(12, 12, 22)
        window.decorView.systemUiVisibility = 0

        val bg = Color.rgb(12, 12, 22)
        val panel = Color.rgb(27, 27, 43)
        val white = Color.WHITE
        val muted = Color.rgb(185, 185, 205)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        content.addView(text("AI VIDEO STUDIO", 13f, Color.rgb(173, 148, 255), true))
        val title = text("अपना वीडियो बनाएं ✨", 28f, white, true)
        title.setPadding(0, dp(10), 0, dp(6))
        content.addView(title)
        content.addView(text("फोटो या Prompt से Shorts बनाने की शुरुआत करें।", 15f, muted))
        addSpace(content, 22)

        content.addView(text("1. अपनी फोटो चुनें", 18f, white, true))
        addSpace(content, 8)
        val photoButton = button("＋  फोटो चुनें")
        content.addView(photoButton, matchWrap())
        imageStatus = text("अभी कोई फोटो नहीं चुनी गई", 13f, muted)
        imageStatus.setPadding(dp(4), dp(8), 0, dp(8))
        content.addView(imageStatus)
        photoButton.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }
            startActivityForResult(Intent.createChooser(intent, "फोटो चुनें"), 101)
        }

        addSpace(content, 12)
        content.addView(text("2. वीडियो का Prompt लिखें", 18f, white, true))
        addSpace(content, 8)
        promptInput = EditText(this).apply {
            hint = "उदाहरण: गुलाबी बाइक पर सिनेमैटिक स्टंट..."
            setHintTextColor(Color.rgb(135, 135, 160))
            setTextColor(white)
            textSize = 15f
            gravity = Gravity.TOP
            minLines = 4
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(panel, 16)
        }
        content.addView(promptInput, LinearLayout.LayoutParams(-1, dp(132)))

        addSpace(content, 16)
        content.addView(text("3. वीडियो का फ़ॉर्मेट", 18f, white, true))
        addSpace(content, 8)
        val format = Spinner(this)
        val options = arrayOf("YouTube Shorts · 9:16", "Landscape · 16:9", "Square · 1:1")
        format.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, options)
        format.background = rounded(panel, 12)
        content.addView(format, LinearLayout.LayoutParams(-1, dp(52)))

        addSpace(content, 22)
        generateButton = button("✨  AI वीडियो बनाएं")
        content.addView(generateButton, matchWrap())
        generateButton.setOnClickListener {
            val prompt = promptInput.text.toString().trim()
            if (prompt.isEmpty()) {
                Toast.makeText(this, "पहले वीडियो का Prompt लिखें।", Toast.LENGTH_LONG).show()
            } else {
                AlertDialog.Builder(this)
                    .setTitle("AI सेवा जोड़ना बाकी है")
                    .setMessage("आपका ऐप इंटरफ़ेस तैयार है। असली वीडियो जनरेट करने के लिए AI video API/service जोड़नी होगी। यह starter build अभी वीडियो जनरेट नहीं करता।")
                    .setPositiveButton("ठीक है", null)
                    .show()
            }
        }

        addSpace(content, 16)
        val note = text("नोट: यह शुरुआती ऐप प्रोजेक्ट है। AI वीडियो जनरेशन API अभी कनेक्ट नहीं है।", 12f, muted)
        content.addView(note)
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun addSpace(parent: LinearLayout, height: Int) {
        parent.addView(android.view.View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            selectedImage = data?.data
            imageStatus.text = if (selectedImage != null) "फोटो चुन ली गई ✓" else "अभी कोई फोटो नहीं चुनी गई"
        }
    }
}
